import Link from "next/link";

const categories = ["Elektronik","Moda","Ev & Yaşam","Spor","Kozmetik","Oyun"];

const products = [
  {id:1,name:"Kablosuz Kulaklık Pro",price:"1.499 TL",emoji:"🎧"},
  {id:2,name:"Akıllı Saat X3",price:"2.899 TL",emoji:"⌚"},
  {id:3,name:"Gaming Mekanik Klavye",price:"1.799 TL",emoji:"⌨️"},
  {id:4,name:"Premium Sırt Çantası",price:"899 TL",emoji:"🎒"}
];

export default function Home() {
  return <>
    <section className="hero">
      <div className="container">
        <span className="badge">PAZARX MARKETPLACE</span>
        <h1>Aradığın her şey,<br/>tek pazarda.</h1>
        <p>Binlerce ürün, güvenilir satıcılar ve kolay alışveriş deneyimi. PazarX ile keşfet, karşılaştır ve satın al.</p>
        <Link className="btn btn-primary" href="/products">Alışverişe Başla →</Link>
      </div>
    </section>
    <section className="section">
      <div className="container">
        <h2>Kategoriler</h2>
        <div className="category-grid">{categories.map(c=><Link className="category" href="/products" key={c}>{c}</Link>)}</div>
      </div>
    </section>
    <section className="section">
      <div className="container">
        <h2>Öne Çıkan Ürünler</h2>
        <div className="grid">{products.map(p=><Link className="card" href={"/products/"+p.id} key={p.id}><div className="product-image">{p.emoji}</div><div className="card-body"><span className="badge">Çok Satan</span><h3>{p.name}</h3><div className="price">{p.price}</div><div className="muted">Ücretsiz kargo</div></div></Link>)}</div>
      </div>
    </section>
  </>;
}