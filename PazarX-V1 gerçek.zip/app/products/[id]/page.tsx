import Link from "next/link";

export default async function Product({params}:{params:Promise<{id:string}>}){
 const {id}=await params;
 return <main className="section"><div className="container"><div className="card" style={{maxWidth:900,margin:"auto"}}><div className="product-image" style={{height:360}}>🛍️</div><div className="card-body"><span className="badge">PazarX Güvencesi</span><h1>Kablosuz Kulaklık Pro</h1><p className="muted">Yüksek kaliteli ses, uzun pil ömrü ve konforlu kullanım.</p><div className="price">1.499 TL</div><p>★★★★★ (128 değerlendirme)</p><button className="btn" style={{background:"#6d28d9",color:"#fff"}}>Sepete Ekle</button> <Link className="btn" style={{background:"#eee"}} href="/cart">Sepete Git</Link><p className="muted">Ürün no: {id} · 2 yıl garanti · Ücretsiz kargo</p></div></div></div></main>
}