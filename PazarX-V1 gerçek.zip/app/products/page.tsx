import Link from "next/link";

const products = Array.from({length:12},(_,i)=>({
 id:i+1,name:["Kablosuz Kulaklık Pro","Akıllı Saat X3","Gaming Mekanik Klavye","Premium Sırt Çantası"][i%4],
 price:["1.499 TL","2.899 TL","1.799 TL","899 TL"][i%4],
 emoji:["🎧","⌚","⌨️","🎒"][i%4]
}));

export default function Products(){
 return <main className="section"><div className="container"><h1>Ürünler</h1><p className="muted">PazarX ürün kataloğu</p><div className="grid">{products.map(p=><Link className="card" href={"/products/"+p.id} key={p.id}><div className="product-image">{p.emoji}</div><div className="card-body"><span className="badge">PazarX</span><h3>{p.name}</h3><div className="price">{p.price}</div><div className="muted">★★★★★ · Ücretsiz kargo</div></div></Link>)}</div></div></main>
}